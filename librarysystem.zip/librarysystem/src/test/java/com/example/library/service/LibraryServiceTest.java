package com.example.library.service;

import com.example.library.dto.BorrowerDTO;
import com.example.library.dto.BookDTO;
import com.example.library.model.Book;
import com.example.library.model.Borrower;
import com.example.library.repository.BookRepository;
import com.example.library.repository.BorrowerRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LibraryServiceTest {

    @Mock
    private BookRepository bookRepository;

    @Mock
    private BorrowerRepository borrowerRepository;

    @InjectMocks
    private LibraryService libraryService;

    public LibraryServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterBorrower() {
        BorrowerDTO borrowerDTO = new BorrowerDTO();
        borrowerDTO.setName("Sandun Wedage");
        borrowerDTO.setEmail("sandun.wedage@example.com");

        Borrower borrower = new Borrower();
        borrower.setName("Sandun Wedage");
        borrower.setEmail("sandun.wedage@example.com");

        when(borrowerRepository.save(any(Borrower.class))).thenReturn(borrower);

        Borrower registeredBorrower = libraryService.registerBorrower(borrowerDTO);

        assertEquals("Sandun Wedage", registeredBorrower.getName());
        assertEquals("sandun.wedage@example.com", registeredBorrower.getEmail());
    }

    @Test
    public void testRegisterBook() {
        BookDTO bookDTO = new BookDTO();
        bookDTO.setIsbn("1234567890");
        bookDTO.setTitle("Sample Book");
        bookDTO.setAuthor("Author Name");

        Book book = new Book();
        book.setIsbn("1234567890");
        book.setTitle("Sample Book");
        book.setAuthor("Author Name");

        when(bookRepository.save(any(Book.class))).thenReturn(book);

        Book registeredBook = libraryService.registerBook(bookDTO);

        assertEquals("1234567890", registeredBook.getIsbn());
        assertEquals("Sample Book", registeredBook.getTitle());
        assertEquals("
