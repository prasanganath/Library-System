package com.example.library.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.awt.PageAttributes.MediaType;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.library.dto.BookDTO;
import com.example.library.dto.BorrowerDTO;
import com.example.library.model.Book;
import com.example.library.service.LibraryService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(LibraryController.class)
public class LibraryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LibraryService libraryService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testRegisterBorrower() throws Exception {
        BorrowerDTO borrowerDTO = new BorrowerDTO();
        borrowerDTO.setName("John Doe");
        borrowerDTO.setEmail("john.doe@example.com");

        Mockito.when(libraryService.registerBorrower(Mockito.any(BorrowerDTO.class)))
                .thenReturn(borrowerDTO);

        mockMvc.perform(post("/api/borrowers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(borrowerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Sandun Wedage"))
                .andExpect(jsonPath("$.email").value("sandun.wedage@example.com"))
                .andDo(print());
    }

    @Test
    public void testRegisterBook() throws Exception {
        BookDTO bookDTO = new BookDTO();
        bookDTO.setIsbn("1234567890");
        bookDTO.setTitle("Sample Book");
        bookDTO.setAuthor("Author Name");

        Mockito.when(libraryService.registerBook(Mockito.any(BookDTO.class)))
                .thenReturn(bookDTO);

        mockMvc.perform(post("/api/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(bookDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isbn").value("1234567890"))
                .andExpect(jsonPath("$.title").value("Sample Book"))
                .andExpect(jsonPath("$.author").value("Author Name"))
                .andDo(print());
    }

    @Test
    public void testGetAllBooks() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setIsbn("1234567890");
        book.setTitle("Sample Book");
        book.setAuthor("Author Name");

        Mockito.when(libraryService.getAllBooks())
                .thenReturn(Collections.singletonList(book));

        mockMvc.perform(get("/api/books")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].isbn").value("1234567890"))
                .andExpect(jsonPath("$[0].title").value("Sample Book"))
                .andExpect(jsonPath("$[0].author").value("Author Name"))
                .andDo(print());
    }

    @Test
    public void testBorrowBook() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setIsbn("1234567890");
        book.setTitle("Sample Book");
        book.setAuthor("Author Name");
        book.setBorrowed(true);

        Mockito.when(libraryService.borrowBook(1L))
                .thenReturn(book);

        mockMvc.perform(post("/api/books/1/borrow")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.isBorrowed").value(true))
                .andDo(print());
    }

    @Test
    public void testReturnBook() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setIsbn("1234567890");
        book.setTitle("Sample Book");
        book.setAuthor("Author Name");
        book.setBorrowed(false);

        Mockito.when(libraryService.returnBook(1L))
                .thenReturn(book);

        mockMvc.perform(post("/api/books/1/return")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.isBorrowed").value(false))
                .andDo(print());
    }
}
