package com.example.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.library.dto.BookDTO;
import com.example.library.dto.BorrowerDTO;
import com.example.library.model.Book;
import com.example.library.service.LibraryService;

@RestController
@RequestMapping("/api")
public class LibraryController {

    @Autowired
    private LibraryService libraryService;

    @PostMapping("/borrowers")
    public BorrowerDTO registerBorrower(@RequestBody BorrowerDTO borrowerDTO) {
        return libraryService.registerBorrower(borrowerDTO);
    }

    @PostMapping("/books")
    public BookDTO registerBook(@RequestBody BookDTO bookDTO) {
        return libraryService.registerBook(bookDTO);
    }

    @GetMapping("/books")
    public List<Book> getAllBooks() {
        return libraryService.getAllBooks();
    }

    @PostMapping("/books/{bookId}/borrow")
    public Book borrowBook(@PathVariable Long bookId) {
        return libraryService.borrowBook(bookId);
    }

    @PostMapping("/books/{bookId}/return")
    public Book returnBook(@PathVariable Long bookId) {
        return libraryService.returnBook(bookId);
    }
}
