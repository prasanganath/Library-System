package com.example.library.dto;

import lombok.Data;

@Data
public class BorrowerDTO {
    private String name;
    private String email;
}
