INSERT INTO BORROWER (name, email) VALUES ('John Doe', 'john.doe@example.com');
INSERT INTO BOOK (isbn, title, author, is_borrowed) VALUES ('1234567890', 'Sample Book', 'Author Name', false);
